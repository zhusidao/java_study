package com.hainet.spring.test.dbunit.sample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringTestDbunitSampleApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringTestDbunitSampleApplication.class, args);
    }
}
